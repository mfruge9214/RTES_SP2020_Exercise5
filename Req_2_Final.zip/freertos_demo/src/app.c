/*************************
 * File: app.c
 *      This file implements all tasks required in Real Time Embedded Systems, HW3
 *
 * Author: Mike Fruge
 */

#include <stdio.h>
#include <stdbool.h>

#include "app.h"
#include "utils/uartstdio.h"

// From example
#include "inc/tm4c123gh6pm.h"
#include "inc/hw_memmap.h"
#include "inc/hw_types.h"

#include "driverlib/sysctl.h"
#include "driverlib/interrupt.h"
#include "driverlib/gpio.h"
#include "driverlib/timer.h"
#include "driverlib/systick.h"

#include "task.h"
#include "semphr.h"
#include "queue.h"


//QueueHandle_t LogMsgQueue;

//
//SemaphoreHandle_t ExecutionSmphr;
//SemaphoreHandle_t SequencerSmphr;
//SemaphoreHandle_t ServiceSmphrs[NUM_SERVICES];


static bool abortS1;
static bool abortS2;
static bool abortS3;
static bool abortS4;
static bool abortS5;
static bool abortS6;
static bool abortS7;

//static uint32_t count = 0;

uint32_t taskTime;


/*
 * Fibinacci Generation
 *      Used to generate synthetic loads
 *
 *      Thread safe function for generating synthetic loads
 */


void FibLoad(uint32_t seqCnt, uint32_t iterCnt)
{
   uint32_t idx = 0, jdx = 1;
   uint32_t fib = 0, fib0 = 0, fib1 = 1;

   for(idx=0; idx < iterCnt; idx++)
   {
      fib = fib0 + fib1;
      while(jdx < seqCnt)
      {
         fib0 = fib1;
         fib1 = fib;
         fib = fib0 + fib1;
         jdx++;
      }
   }
}

/*
 * Systick Handler
 *      Freq: 30 Hz
 *      Used to convert HW event (Systick timer interrupt) into signal for sequencer to run
 */

void mySysTickHandler(void)
{
    static BaseType_t xHigherPriorityTaskWoken = pdFALSE;
    if(!abortS1)
    {
        vTaskNotifyGiveFromISR(thSequencer, &xHigherPriorityTaskWoken);
        portYIELD_FROM_ISR(xHigherPriorityTaskWoken);

    }

}

//*****************************************************************************
//
// The interrupt handler for the Timer interrupt.
//
//*****************************************************************************
void myTimerIntHandler(void)
{
    //
    // Clear the timer interrupt flag.
    //
    TimerIntClear(TIMER0_BASE, TIMER_TIMA_TIMEOUT);

    //
    // Update the periodic interrupt counter.
    //
    taskTime ++;

}

/*
 * SequencerTask
 *      Initializes and waits for periodic signal from the Systick
 *
 *      Releases services used for processing based of of signal count
 */

void SequencerTask(void* pvParameters)
{
    // Create queue for messages
    LogMsgQueue = xQueueCreate(1024, sizeof(MessageStruct_t));

    MessageStruct_t report;
//    count = 0;
    // Configure Systick for 30 Hz interrupts
    SysTickIntRegister(mySysTickHandler);
    SysTickPeriodSet(CLOCK_FREQ/(SYSTICK_FREQ));
    SysTickIntEnable();
    SysTickEnable();

    uint32_t count = 0;
    uint32_t taskTime = 0;

    BaseType_t NotifReceived;
    uint32_t ulNotificationValue;


    // Configure Timer 0 to keep track of WCET's

    SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER0);

    TimerConfigure(TIMER0_BASE, TIMER_CFG_SPLIT_PAIR | TIMER_CFG_A_PERIODIC);

    TimerLoadSet(TIMER0_BASE, TIMER_A, SysCtlClockGet()/1000);       // 1 ms intervals

    IntMasterEnable();

        //
        // Configure the Timer0A interrupt for timer timeout.
        //
    TimerIntEnable(TIMER0_BASE, TIMER_TIMA_TIMEOUT);
    IntEnable(INT_TIMER0A);
    xSemaphoreGive(TimerSmphr);


    while(1)
    {
        // Wait for notification from Systick Handler
            // param    Clear Count On Exit
            // param    Max Block Time
        if(ulTaskNotifyTake(pdTRUE, portMAX_DELAY))
        {
//            UARTprintf(" Received Notif: %d \n", count);
            count++;
            if(count > 1000)
            {
                abortS1 = abortS2 = abortS3 = abortS4 = abortS5 = abortS6 = abortS7 = 1;
//                SysTickDisable();
//                xTaskNotifyWait(pdFALSE, 0xFFFFFFFF, &ulNotificationValue, portMAX_DELAY);

//                if(ulNotificationValue & 0xFFFF )
//                {
                    while (xQueueReceive(LogMsgQueue, &report, (TickType_t) 10))
                    {
                        UARTprintf(" Service %d: Run Number: %d Elapsed Time: %d mS\n", report.taskNum, report.ExecutionNum, report.timeElapsed);
                    }

                    vQueueDelete(LogMsgQueue);
                    vTaskDelete(NULL);
//                }

            }

//            UARTprintf(" Received Notification %d \n", count);

            if(count % 10 == 0)
            {
                xSemaphoreGive(ServiceSmphrs[GET_FRAME]);
            }

            if(count % 30 == 0)
            {
                xSemaphoreGive(ServiceSmphrs[IMG_ANALYSIS]);
                xSemaphoreGive(ServiceSmphrs[SAVE_TIMESTAMP]);
                xSemaphoreGive(ServiceSmphrs[SEND_IMG]);
            }

            if(count % 60 == 0)
            {
                xSemaphoreGive(ServiceSmphrs[IMG_PROC]);
                xSemaphoreGive(ServiceSmphrs[SAVE_IMG]);
            }

            if(count % 300 == 0)
            {
                xSemaphoreGive(ServiceSmphrs[LOGGER]);
            }
        }
    }
}

void GetFrameTask(void *pvParameters)
{
    uint32_t i = 0;
    uint32_t cnt_diff = 0;
    uint32_t S1Cnt=0;
    uint32_t iterCnt = 3;
    uint32_t seqCnt = TEN_MS_FIB_LOOP;
    uint32_t idx = 0, jdx = 1;
    uint32_t fib = 0, fib0 = 0, fib1 = 1;

    MessageStruct_t message;
    message.taskNum = 1;

    while(!abortS1)
    {
        if(xSemaphoreTake(ServiceSmphrs[GET_FRAME], portMAX_DELAY))
        {
            if(xSemaphoreTake(TimerSmphr, (TickType_t) 5))
            {
                taskTime = 0;
//            start_time = xTaskGetTickCount();
                TimerEnable(TIMER0_BASE, TIMER_A);
    //            start_cnt = count;
                S1Cnt++;

                for(idx=0; idx < iterCnt; idx++)
                {
                   fib = fib0 + fib1;
                   while(jdx < seqCnt)
                   {
                      fib0 = fib1;
                      fib1 = fib;
                      fib = fib0 + fib1;
                      jdx++;
                   }
                   jdx = 0;
                }
                TimerDisable(TIMER0_BASE, TIMER_A);
                cnt_diff = taskTime;
                xSemaphoreGive(TimerSmphr);
            }
            message.timeElapsed = cnt_diff;
            message.ExecutionNum = S1Cnt;
            xQueueSend(LogMsgQueue, (void*) &message, (TickType_t) 0);
        }
    }
    vTaskDelete(NULL);
}

void ImgAnalysisTask(void *pvParameters)
{
    uint8_t i = 0;
    uint32_t cnt_diff = 0;
    uint32_t S2Cnt=0;
    MessageStruct_t message;
    message.taskNum = 2;
    uint32_t iterCnt = 9;
    uint32_t seqCnt = TEN_MS_FIB_LOOP;
    uint32_t idx = 0, jdx = 1;
    uint32_t fib = 0, fib0 = 0, fib1 = 1;

    while(!abortS2)
    {
        if(xSemaphoreTake(ServiceSmphrs[IMG_ANALYSIS], portMAX_DELAY))
        {
            if(xSemaphoreTake(TimerSmphr, (TickType_t) 5))
            {
                taskTime = 0;
//            start_time = xTaskGetTickCount();
                TimerEnable(TIMER0_BASE, TIMER_A);
    //            start_cnt = count;
                S2Cnt++;

                for(idx=0; idx < iterCnt; idx++)
                {
                   fib = fib0 + fib1;
                   while(jdx < seqCnt)
                   {
                      fib0 = fib1;
                      fib1 = fib;
                      fib = fib0 + fib1;
                      jdx++;
                   }
                   jdx = 0;
                }
                TimerDisable(TIMER0_BASE, TIMER_A);
                cnt_diff = taskTime;
                taskTime = 0;
                xSemaphoreGive(TimerSmphr);
            }
            message.timeElapsed = cnt_diff;
            message.ExecutionNum = S2Cnt;
            xQueueSend(LogMsgQueue, (void*) &message, (TickType_t) 0);

        }
    }
    vTaskDelete(NULL);
}

void SaveTimestampTask(void *pvParameters)
{
    uint8_t i = 0;
    uint32_t cnt_diff = 0;
    uint32_t S4Cnt=0;

    uint32_t iterCnt = 9;
    uint32_t seqCnt = TEN_MS_FIB_LOOP;
    uint32_t idx = 0, jdx = 1;
    uint32_t fib = 0, fib0 = 0, fib1 = 1;

    MessageStruct_t message;
    message.taskNum = 4;

    while(!abortS4)
    {
        if(xSemaphoreTake(ServiceSmphrs[SAVE_TIMESTAMP], portMAX_DELAY))
        {
            if(xSemaphoreTake(TimerSmphr, (TickType_t) 5))
            {
                taskTime = 0;
//            start_time = xTaskGetTickCount();
                TimerEnable(TIMER0_BASE, TIMER_A);
    //            start_cnt = count;
                S4Cnt++;

                for(idx=0; idx < iterCnt; idx++)
                {
                   fib = fib0 + fib1;
                   while(jdx < seqCnt)
                   {
                      fib0 = fib1;
                      fib1 = fib;
                      fib = fib0 + fib1;
                      jdx++;
                   }
                   jdx = 0;
                }
                TimerDisable(TIMER0_BASE, TIMER_A);
                cnt_diff = taskTime;
                xSemaphoreGive(TimerSmphr);
            }
            message.timeElapsed = cnt_diff;
            message.ExecutionNum = S4Cnt;
            xQueueSend(LogMsgQueue, (void*) &message, (TickType_t) 0);

        }
    }
    vTaskDelete(NULL);
}

void SendImgTask(void *pvParameters)
{
    uint8_t i = 0;
    uint32_t cnt_diff = 0;
    uint32_t S6Cnt=0;

    uint32_t iterCnt = 9;
    uint32_t seqCnt = TEN_MS_FIB_LOOP;
    uint32_t idx = 0, jdx = 1;
    uint32_t fib = 0, fib0 = 0, fib1 = 1;

    MessageStruct_t message;
    message.taskNum = 6;

    while(!abortS6)
    {
        if(xSemaphoreTake(ServiceSmphrs[SEND_IMG], portMAX_DELAY))
        {
            if(xSemaphoreTake(TimerSmphr, (TickType_t) 5))
            {
                taskTime = 0;
//            start_time = xTaskGetTickCount();
                TimerEnable(TIMER0_BASE, TIMER_A);
    //            start_cnt = count;
                S6Cnt++;

                for(idx=0; idx < iterCnt; idx++)
                {
                   fib = fib0 + fib1;
                   while(jdx < seqCnt)
                   {
                      fib0 = fib1;
                      fib1 = fib;
                      fib = fib0 + fib1;
                      jdx++;
                   }
                   jdx = 0;
                }
                TimerDisable(TIMER0_BASE, TIMER_A);
                cnt_diff = taskTime;
                xSemaphoreGive(TimerSmphr);
            }
            message.timeElapsed = cnt_diff;
            message.ExecutionNum = S6Cnt;
            xQueueSend(LogMsgQueue, (void*) &message, (TickType_t) 0);
        }
    }
    vTaskDelete(NULL);
}

void ImgProcTask(void *pvParameters)
{
    uint8_t i = 0;
    uint32_t cnt_diff = 0;
    uint32_t S3Cnt=0;

    uint32_t iterCnt = 30;
    uint32_t seqCnt = TEN_MS_FIB_LOOP;
    uint32_t idx = 0, jdx = 1;
    uint32_t fib = 0, fib0 = 0, fib1 = 1;

    MessageStruct_t message;
    message.taskNum = 3;


    while(!abortS3)
    {
        if(xSemaphoreTake(ServiceSmphrs[IMG_PROC], portMAX_DELAY))
        {
            if(xSemaphoreTake(TimerSmphr, (TickType_t) 5))
            {
                taskTime = 0;
//            start_time = xTaskGetTickCount();
                TimerEnable(TIMER0_BASE, TIMER_A);
    //            start_cnt = count;
                S3Cnt++;

                for(idx=0; idx < iterCnt; idx++)
                {
                   fib = fib0 + fib1;
                   while(jdx < seqCnt)
                   {
                      fib0 = fib1;
                      fib1 = fib;
                      fib = fib0 + fib1;
                      jdx++;
                   }
                   jdx = 0;
                }
                TimerDisable(TIMER0_BASE, TIMER_A);
                cnt_diff = taskTime;
                xSemaphoreGive(TimerSmphr);
            }
            message.timeElapsed = cnt_diff;
            message.ExecutionNum = S3Cnt;
            xQueueSend(LogMsgQueue, (void*) &message, (TickType_t) 0);

        }
    }
    vTaskDelete(NULL);
}


void SaveImgTask(void *pvParameters)
{
    uint8_t i = 0;
    uint32_t cnt_diff = 0;
    uint32_t S5Cnt = 0;

    uint32_t iterCnt = 30;
    uint32_t seqCnt = TEN_MS_FIB_LOOP;
    uint32_t idx = 0, jdx = 1;
    uint32_t fib = 0, fib0 = 0, fib1 = 1;

    MessageStruct_t message;
    message.taskNum = 5;

    while(!abortS5)
    {
        if(xSemaphoreTake(ServiceSmphrs[SAVE_IMG], portMAX_DELAY))
        {
            if(xSemaphoreTake(TimerSmphr, (TickType_t) 5))
            {
//            start_time = xTaskGetTickCount();
                taskTime = 0;
                TimerEnable(TIMER0_BASE, TIMER_A);
                S5Cnt++;

                for(idx=0; idx < iterCnt; idx++)
                {
                   fib = fib0 + fib1;
                   while(jdx < seqCnt)
                   {
                      fib0 = fib1;
                      fib1 = fib;
                      fib = fib0 + fib1;
                      jdx++;
                   }
                   jdx = 0;
                }
                TimerDisable(TIMER0_BASE, TIMER_A);
                cnt_diff = taskTime;
                xSemaphoreGive(TimerSmphr);
            }
            message.timeElapsed = cnt_diff;
            message.ExecutionNum = S5Cnt;
            xQueueSend(LogMsgQueue, (void*) &message, (TickType_t) 0);
        }
    }
    vTaskDelete(NULL);
}

void LoggerTask(void *pvParameters)
{
    uint8_t i = 0;
    uint32_t cnt_diff = 0;
    uint32_t S7Cnt=0;

    uint32_t iterCnt = 100;
    uint32_t seqCnt = TEN_MS_FIB_LOOP;
    uint32_t idx = 0, jdx = 1;
    uint32_t fib = 0, fib0 = 0, fib1 = 1;


    MessageStruct_t message;
    message.taskNum = 7;

    while(!abortS7)
    {
        if(xSemaphoreTake(ServiceSmphrs[LOGGER], portMAX_DELAY))
        {
            if(xSemaphoreTake(TimerSmphr, (TickType_t) 5))
            {

                taskTime = 0;
                TimerEnable(TIMER0_BASE, TIMER_A);
    //            start_cnt = count;
                S7Cnt++;

                for(idx=0; idx < iterCnt; idx++)
                {
                   fib = fib0 + fib1;
                   while(jdx < seqCnt)
                   {
                      fib0 = fib1;
                      fib1 = fib;
                      fib = fib0 + fib1;
                      jdx++;
                   }
                   jdx = 0;
                }
                TimerDisable(TIMER0_BASE, TIMER_A);
                cnt_diff = taskTime;

                xSemaphoreGive(TimerSmphr);
            }
            message.timeElapsed = cnt_diff;
            message.ExecutionNum = S7Cnt;
            xQueueSend(LogMsgQueue, (void*) &message, (TickType_t) 0);
        }
    }
//    xTaskNotify(thSequencer, 0xFFFF, eSetBits);
    vTaskDelete(NULL);
}




//void Fib10Task(void* prvParameters){
////    idx = 0;
////    jdx = 1;
////    fib = 0;
////    fib0 = 0;
////    fib1 = 1;
//
//    BaseType_t NotifReceived;
//    uint32_t ulNotificationValue;
//    TickType_t start_time, end_time;
//    uint32_t numCalculations, timeTaken = 0;
//    float avg_time = 0;
//
//    while(1)
//    {
////        ulTaskNotifyTake(pdTRUE, portMAX_DELAY);    // Wait for notification from timer
//
//        if(xSemaphoreTake(ServiceSmphrs[GET_FRAME], portMAX_DELAY))   // Attempt to grab semaphore
//        {
//            start_time = xTaskGetTickCount();
//
//            FibLoad(FIB_LIMIT_FOR_32_BIT, TEN_MS_FIB_LOOP);
//
//            end_time = xTaskGetTickCount();
//
//            numCalculations++;
//            timeTaken += (uint32_t) (end_time - start_time);
//            avg_time = timeTaken/numCalculations;
//
//           UARTprintf("Service 1: Took %d milliseconds\n", (uint32_t) (end_time - start_time));
////           xSemaphoreGive(ExecutionSmphr);
////           vTaskDelay(pdMS_TO_TICKS(2));
//       }
//    }
//
//}
//
//
//void Fib40Task(void* prvParameters){
//
//    BaseType_t NotifReceived;
//    uint32_t ulNotificationValue;
//    TickType_t start_time, end_time;
//    uint32_t numCalculations, timeTaken = 0;
//    float avg_time = 0;
//
//    while(1)
//    {
//        ulTaskNotifyTake(pdTRUE, portMAX_DELAY);
//
//        /* Take semaphore for access to global variables to begin computation */
//        if(xSemaphoreTake(ExecutionSmphr, portMAX_DELAY))
//        {
//
////            idx = fib = fib0 = 0;
////            jdx = fib1 = 1;
//
//            start_time = xTaskGetTickCount();
//
////            FIB_TEST(FIB_LIMIT_FOR_32_BIT, FORTY_MS_FIB_LOOP);
//
//            end_time = xTaskGetTickCount();
//
//            numCalculations++;
//            timeTaken += (uint32_t) (end_time - start_time);
//            avg_time = timeTaken/numCalculations;
//
//            UARTprintf("Service 2: %d milliseconds\n", (uint32_t) (end_time - start_time));
//            xSemaphoreGive(ExecutionSmphr);
//            vTaskDelay(pdMS_TO_TICKS(2));
//
//        }
//
//    }
//
//}

//void myTimerCallback(TimerHandle_t timer)
//{
//    TickType_t curr_time;
//    uint32_t count = (uint32_t) pvTimerGetTimerID(timer);
//
//    count++;
//
//    if(count <25)
//    {
//        // Notify Fib10
//        if(count % 3 == 0) xTaskNotifyGive(thFib10);
//
//        // Notify Fib40
//        if(count % 8 == 0) xTaskNotifyGive(thFib40);
//    }
//
//    /* Set Timer ID equal to new count */
//    vTimerSetTimerID(timer, (void*) count);
//
//}
