/*************************
 * File: app.c
 *      This header file declares all tasks, variables, and defines required in Real Time Embedded Systems, HW3
 *
 * Author: Mike Fruge
 */

#include <stdint.h>


#include "FreeRTOS.h"
#include "timers.h"
#include "semphr.h"

#define FIB_LIMIT_FOR_32_BIT    20U

#define CLOCK_FREQ      50000000
#define SYSTICK_FREQ        30

#define TEN_MS_FIB_LOOP         61000U
#define FORTY_MS_FIB_LOOP       195000U

#define NUM_SERVICES    7

// Service Definitions
#define GET_FRAME               0
#define IMG_ANALYSIS            1
#define IMG_PROC                2
#define SAVE_TIMESTAMP          3
#define SAVE_IMG                4
#define SEND_IMG                5
#define LOGGER                  6


/* Struct to hold messages */

typedef struct {
    uint8_t taskNum;
    uint8_t timeElapsed;
    uint8_t ExecutionNum;
} MessageStruct_t;



/* Create a message queue to be read out after test has concluded */
QueueHandle_t LogMsgQueue;

SemaphoreHandle_t TimerSmphr;
SemaphoreHandle_t SequencerSmphr;
SemaphoreHandle_t ServiceSmphrs[NUM_SERVICES];


TaskHandle_t thFib10;

TaskHandle_t thSequencer;
TaskHandle_t thGetFrame;
TaskHandle_t thImgAnalysis;
TaskHandle_t thImgProc;
TaskHandle_t thSaveTimestamp;
TaskHandle_t thSaveImg;
TaskHandle_t thSendImg;
TaskHandle_t thLogger;


void myTimerIntHandler(void);
void FibLoad(uint32_t seqCnt, uint32_t iterCnt);

void SequencerTask(void* prvParameters);
void GetFrameTask(void* prvParameters);
void ImgAnalysisTask(void *pvParameters);
void SaveTimestampTask(void *pvParameters);
void SendImgTask(void *pvParameters);
void ImgProcTask(void *pvParameters);
void SaveImgTask(void *pvParameters);
void LoggerTask(void *pvParameters);
void Fib10Task(void* prvParameters);
void Fib40Task(void* prvParameters);

//void myTimerCallback(TimerHandle_t timer);
