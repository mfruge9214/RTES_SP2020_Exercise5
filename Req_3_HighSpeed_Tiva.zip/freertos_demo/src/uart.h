#include <stdint.h>


void ConfigureUART(void);
